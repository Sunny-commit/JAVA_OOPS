package Advanced_Topics;

class Book {
    private String title;
    private String author;
    private String genre;

    public Book(String t, String a, String g) {
        title = t;
        author = a;
        genre = g;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public String toString() {
        return getClass().getName() + "[title=" + title + ", author=" + author + ", genre=" + genre + "]";
    }
}

public class Exercise4 {
    public static void main(String[] args) {

        //add code below this line
        //add code below this line

        //add code below this line

        Library library = new Library();
        Book book1 = new Book("Three Musketeers", "Alexandre Dumas", "fiction");
        Book book2 = new Book("The Count of Monte Cristo", "Alexandre Dumas", "fiction");
        Book book3 = new Book("Educated", "Tara Westover", "nonfiction");

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);
        library.sortBooks();
        System.out.println(library.getBooks());

        //add code above this line
        //add code above this line


        //add code above this line

    }
}