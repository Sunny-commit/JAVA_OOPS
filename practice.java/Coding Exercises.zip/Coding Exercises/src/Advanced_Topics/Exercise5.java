package Advanced_Topics;

import java.util.*;

class ShoppingCart {
    private ArrayList<Item> items;
    private double total;

    public ShoppingCart() {
        items = new ArrayList<Item>();
        total = 0;
    }

    public void addItem(Item item) {
        items.add(item);
        calculateTotal();
    }

    private void calculateTotal() {
        total = 0;
        for (Item i : items) {
            i.calculateSubtotal();
            total += i.getSubtotal();
        }
    }

    public double getTotal() {
        return total;
    }

    public int getNumItems() {
        int numItems = 0;
        for (Item i : items) {
            numItems += i.getQuantity();
        }
        return numItems;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public String toString() {
        return getClass().getName() + "[items=" + items + ", total=" + total + "]";
    }
}

class Item {
    private String name;
    private double price;
    private int quantity;
    private double subtotal;

    public Item(String n, double p, int q) {
        name = n;
        price = p;
        quantity = q;
        subtotal = 0;
    }

    public int getQuantity() {
        return quantity;
    }

    public void calculateSubtotal() {
        subtotal = price * quantity;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public String toString() {
        return getClass().getName() + "[name=" + name + ", price=" + price + ", quantity=" + quantity + ", subtotal=" + subtotal + "]";
    }
}

public class Exercise5 {
    public static void main(String[] args) {

        ShoppingCart cart = new ShoppingCart();

        cart.addItem(item1);
        cart.addItem(item2);
        cart.addItem(item3);

        System.out.println(cart.getTotal());
        System.out.println(cart.getNumItems());
        System.out.println(cart);
    }
}