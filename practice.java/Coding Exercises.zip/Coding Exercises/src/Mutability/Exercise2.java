package Mutability;

class CelestialBody {
    String name;
    double diameter;
    long distance;
    int moons;

    CelestialBody(String n, double diam, long dist, int m) {
        name = n;
        diameter = diam;
        distance = dist;
        moons = m;
    }
    public static String closerToSun(CelestialBody body1, CelestialBody body2) {
        if (body1.distance < body2.distance) {
            return body1.name;
        } else {
            return body2.name;
        }
    }
}

//add class definitions above this line

public class Exercise2 {
    public static void main(String[] args) {

        //add code below this line

        CelestialBody mercury = new CelestialBody("Mercury", 4879.4, 57909000, 0);
        CelestialBody venus = new CelestialBody("Venus", 12103.6, 108160000, 0);

        //add code above this line
    }
}