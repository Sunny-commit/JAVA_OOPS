package Mutability;

class Subway {
    static double fare = 2.4;
    String[] stops;
    String currentStop;
    String direction;
    int passengers;
    double totalFares;

    Subway() {
        stops = new String[]{"Alewife", "Davis", "Porter", "Harvard", "Central", "Kendall"};
        currentStop = "Alewife";
        direction = "south";
        passengers = 0;
        totalFares = 0;
    }

    // Method to board passengers
    void board(int boardingPassengers) {
        passengers += boardingPassengers;
    }

    // Method to disembark passengers
    void disembark(int exitingPassengers) {
        passengers -= exitingPassengers;
        if (passengers < 0) {
            passengers = 0;
        }
    }

    // Method to advance the subway to the next stop
    void advance() {
        int currentIndex = getIndex(currentStop);
        if (direction.equals("south")) {
            if (currentIndex == stops.length - 1) {
                direction = "north";
                currentStop = stops[currentIndex - 1];
            } else {
                currentStop = stops[currentIndex + 1];
            }
        } else {
            if (currentIndex == 0) {
                direction = "south";
                currentStop = stops[currentIndex + 1];
            } else {
                currentStop = stops[currentIndex - 1];
            }
        }
    }

    // Method to calculate distance to a stop
    int distance(String desiredStop) {
        int currentIndex = getIndex(currentStop);
        int desiredIndex = getIndex(desiredStop);
        return Math.abs(currentIndex - desiredIndex);
    }

    // Method to change the fare
    static void changeFare(double newFare) {
        fare = newFare;
    }

    // Method to calculate fares for boarding passengers
    void calculateFares(int boardingPassengers) {
        totalFares += boardingPassengers * fare;
    }

    // Helper method to get index of a stop
    int getIndex(String stop) {
        for (int i = 0; i < stops.length; i++) {
            if (stops[i].equals(stop)) {
                return i;
            }
        }
        return -1;
    }
}

public class Exercise5 {
    public static void main(String[] args) {
        Subway subway = new Subway();

        // Testing methods
        subway.board(45);
        System.out.println("Passengers after boarding: " + subway.passengers);

        subway.calculateFares(100);
        System.out.println("Total fares: " + subway.totalFares);

        subway.disembark(23);
        System.out.println("Passengers after disembarking: " + subway.passengers);

        subway.advance();
        System.out.println("Current stop after advancing: " + subway.currentStop);
        System.out.println("Direction after advancing: " + subway.direction);

        int distance = subway.distance("Central");
        System.out.println("Distance to Central: " + distance + " stops");

        Subway.changeFare(2.75);
        System.out.println("New fare: " + Subway.fare);
    }
}