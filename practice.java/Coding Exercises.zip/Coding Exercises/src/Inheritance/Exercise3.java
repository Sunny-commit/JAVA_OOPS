package Inheritance;

class Parent1 {
    public String identify() {
        return "This method is called from Parent1";
    }
}

class Parent2 {
    public String identify() {
        return "This method is called from Parent2";
    }
}

class Child extends Parent2{
    public String identify() {
        return "This method is called from Child";
    }

    public String identify2() {
        return super.identify();
    }

    public String identify3() {
        return new Parent1().identify();
    }
}

public class Exercise3 {
    public static void main(String[] args) {
        // Instantiate a Child object
        Child childObject = new Child();

        // Print statements to test the behavior
        System.out.println(childObject.identify());
        System.out.println(childObject.identify2());
        System.out.println(childObject.identify3());
    }
}