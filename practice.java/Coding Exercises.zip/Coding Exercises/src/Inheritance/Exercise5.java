package Inheritance;

class Person {
    private String name;
    private String address;

    public Person(String n, String a) {
        name = n;
        address = a;
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String newAddress) {
        address = newAddress;
    }

    public String info() {
        return name + " lives at " + address + ".";
    }
}

class CardHolder extends Person {
    private int accountNumber;
    private double balance;
    private int creditLimit;

    public CardHolder(String name, String address, int accountNumber) {
        super(name, address);
        this.accountNumber = accountNumber;
        this.balance = 0;
        this.creditLimit = 5000;
    }

    public void processSale(double saleAmount) {
        balance += saleAmount;
        System.out.println("N/A");
    }

    public void makePayment(double paymentAmount) {
        balance -= paymentAmount;
        System.out.println("N/A");
    }

    public double getBalance() {
        return balance;
    }

    public double getCreditLimit() {
        return creditLimit;
    }
}

class PlatinumClient extends CardHolder {
    private double cashBack;
    private double rewards;

    public PlatinumClient(String name, String address, int accountNumber) {
        super(name, address, accountNumber);
        this.cashBack = 0.02;
        this.rewards = 0;
    }

    @Override
    public void processSale(double saleAmount) {
        super.processSale(saleAmount);
        rewards += saleAmount * cashBack;
    }

    public double getRewards() {
        return rewards;
    }
}

public class Exercise5 {
    public static void main(String[] args) {
        // Instantiate a PlatinumClient object
        PlatinumClient p = new PlatinumClient("Sarah", "101 Main Street", 123364);

        // Process sale, make payment, and print balance and rewards
        p.processSale(100);
        System.out.println(p.getRewards()); // Output: 2.0
        System.out.println(p.getBalance()); // Output: 100.0
        p.makePayment(50);
        System.out.println(p.getBalance()); // Output: 50.0

        // Print person information
        System.out.println(p.info()); // Output: Sarah lives at 101 Main Street.
    }
}