package Inheritance;

class Book {
    private String title;
    private String author;
    private String genre;

    public Book(String t, String a, String g) {
        title = t;
        author = a;
        genre = g;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String newTitle) {
        title = newTitle;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String newAuthor) {
        author = newAuthor;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String newGenre) {
        genre = newGenre;
    }
}

class BlogPost extends Book {
    private String website;
    private int wordCount;
    private int pageViews;

    public BlogPost(String title, String author, String genre, String website, int wordCount, int pageViews) {
        super(title, author, genre);
        this.website = website;
        this.wordCount = wordCount;
        this.pageViews = pageViews;
    }

    public String getWebsite() {
        return website;
    }

    public int getWordCount() {
        return wordCount;
    }

    public int getPageViews() {
        return pageViews;
    }
}

public class Exercise2 {
    public static void main(String[] args) {

        // Instantiate a BlogPost object
        BlogPost myPost = new BlogPost("Hot Summer Trends", "Amy Gutierrez", "fashion", "Vogue", 2319, 2748);

        // Print statements to display attributes of the BlogPost object
        System.out.println(myPost.getTitle());
        System.out.println(myPost.getAuthor());
        System.out.println(myPost.getGenre());
        System.out.println(myPost.getWebsite());
        System.out.println(myPost.getWordCount());
        System.out.println(myPost.getPageViews());
    }
}