package Inheritance;

class Bank {
    private String name;
    private int customers;
    private double[] accounts;

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public int getCustomers() {
        return customers;
    }

    public void setCustomers(int newCustomers) {
        customers = newCustomers;
    }

    public double[] getAccounts() {
        return accounts;
    }

    public void setAccounts(double[] newAccounts) {
        accounts = newAccounts;
    }

    public double branchTotal() {
        double total = 0;
        for (double account : accounts) {
            total += account;
        }
        return total;
    }
}

class RegionalBank extends Bank {
    private String name;
    private int customers;
    private double[][] regionalAccounts;

    RegionalBank(String name, int customers, double[][] regionalAccounts) {
        setName(name);
        setCustomers(customers);
        setRegionalAccounts(regionalAccounts);
    }

    public double[][] getRegionalAccounts() {
        return regionalAccounts;
    }

    public void setRegionalAccounts(double[][] newRegionalAccounts) {
        regionalAccounts = newRegionalAccounts;
    }

    public double regionalTotal() {
        double total = 0;
        for (double[] region : regionalAccounts) {
            for (double account : region) {
                total += account;
            }
        }
        return total;
    }
}

public class Exercise4 {
    public static void main(String[] args) {
        // Instantiate a RegionalBank object with the given information
        double[][] accounts = {{10000, 13000, 22000},
                {30000, 7000, 19000},
                {15000, 23000, 31000}};
        RegionalBank rb = new RegionalBank("Main Street Bank", 9, accounts);

        // Print the total amount
        System.out.println(rb.regionalTotal());
    }
}