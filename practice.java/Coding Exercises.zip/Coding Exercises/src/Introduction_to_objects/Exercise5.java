package Introduction_to_objects;

class BigCat {
    static String genus = "panthera";
    String species;
    String commonName;
    String[] habitat;

    BigCat(String species, String commonName, String[] habitat) {
        this.species = species;
        this.commonName = commonName;
        this.habitat = habitat;
    }
}

public class Exercise5 {
    public static void main(String[] args) {

        // Add code below this line
        BigCat tiger = new BigCat("tigris", "tiger", new String[]{"asia"});
        BigCat lion = new BigCat("leo", "lion", new String[]{"africa", "asia"});
        BigCat jaguar = new BigCat("onca", "jaguar", new String[]{"americas"});
        BigCat leopard = new BigCat("pardus", "leopard", new String[]{"africa", "asia"});
        BigCat snowLeopard = new BigCat("uncia", "snow leopard", new String[]{"asia"});

        System.out.println("Species: " + tiger.species + ", Common Name: " + tiger.commonName + ", Habitat: " + String.join(", ", tiger.habitat));
        System.out.println("Species: " + lion.species + ", Common Name: " + lion.commonName + ", Habitat: " + String.join(", ", lion.habitat));
        System.out.println("Species: " + jaguar.species + ", Common Name: " + jaguar.commonName + ", Habitat: " + String.join(", ", jaguar.habitat));
        System.out.println("Species: " + leopard.species + ", Common Name: " + leopard.commonName + ", Habitat: " + String.join(", ", leopard.habitat));
        System.out.println("Species: " + snowLeopard.species + ", Common Name: " + snowLeopard.commonName + ", Habitat: " + String.join(", ", snowLeopard.habitat));
        // Add code above this line
    }
}