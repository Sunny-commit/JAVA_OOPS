package Introduction_to_objects;

public class Exercise1 {

    public static class PracticeClass {
        String date;
    }

    public static void main(String[] args) {

        // Add code below this line
        PracticeClass practiceObj = new PracticeClass();
        practiceObj.date = "2024-04-18"; // Set the date attribute
        System.out.println("Date: " + practiceObj.date); // Output the date attribute
        // Add code above this line
    }
}