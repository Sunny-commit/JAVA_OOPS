package Introduction_to_objects;

//add class definitions below this line

class Observation {
    // Attributes
    String date;
    double temperature;
    double elevation;
    int penguins;
    double precipitation;

    // Constructor
    Observation(String date, double temperature, double elevation, int penguins) {
        this.date = date;
        this.temperature = temperature;
        this.elevation = elevation;
        this.penguins = penguins;
        this.precipitation = 0; // Default precipitation to 0
    }

    // Overloaded constructor to include precipitation
    public Observation(String date, double temperature, double elevation, int penguins, double precipitation) {
        this(date, temperature, elevation, penguins); // Reuse the previous constructor
        this.precipitation = precipitation;
    }

    // Getter methods
    public String getDate() {
        return date;
    }

    public double getTemperature() {
        return temperature;
    }

    public double getElevation() {
        return elevation;
    }

    public int getPenguins() {
        return penguins;
    }

    public double getPrecipitation() {
        return precipitation;
    }


}


//add class definitions above this line

public class Exercise4 {
    public static void main(String[] args) {

        //add code below this line

        Observation antarcticaObservation = new Observation("October 26, 2019", -47.0, 329.4, 3);
        System.out.println("Date: " + antarcticaObservation.getDate());
        System.out.println("Temperature: " + antarcticaObservation.getTemperature() + "°C");
        System.out.println("Elevation: " + antarcticaObservation.getElevation() + " meters");
        System.out.println("Number of Penguins: " + antarcticaObservation.getPenguins());
        System.out.println("Precipitation: " + antarcticaObservation.getPrecipitation() + " cm");

        //add code above this line
    }
}