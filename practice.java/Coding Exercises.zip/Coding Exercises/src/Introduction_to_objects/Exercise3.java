package Introduction_to_objects;

//add class definitions below this line

class Superhero {
    // Attributes
    String name;
    String secretIdentity;
    String[] powers;

    // Constructor
    Superhero(String name, String secretIdentity, String[] powers) {
        this.name = name;
        this.secretIdentity = secretIdentity;
        this.powers = powers;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getSecretIdentity() {
        return secretIdentity;
    }

    public String[] getPowers() {
        return powers;
    }
}
//add class definitions above this line

public class Exercise3 {
    public static void main(String[] args) {

        //add code below this line

        // Testing the code
        String[] powers = {"superhuman strength", "superhuman speed", "superhuman reflexes"};
        Superhero spiderMan = new Superhero("Spider-Man", "Peter Parker", powers);

        System.out.println("Name: " + spiderMan.getName());
        System.out.println("Secret Identity: " + spiderMan.getSecretIdentity());
        System.out.println("Powers:");
        for (String power : spiderMan.getPowers()) {
            System.out.println( power);

            //add code above this line
        }
    }
}