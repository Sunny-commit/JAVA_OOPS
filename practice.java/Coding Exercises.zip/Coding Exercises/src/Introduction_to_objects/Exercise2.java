package Introduction_to_objects;

class Cat {
    String breed;
    String color;
    String name;

    public Cat() {
        breed = "american shorthair";
        color = "black";
        name = "kiwi";
    }
}

// Add class definitions above this line

public class Exercise2 {
    public static void main(String[] args) {

        // Add code below this line
        Cat cat = new Cat();
        System.out.println("Name: " + cat.name);
        System.out.println("Breed: " + cat.breed);
        System.out.println("Color: " + cat.color);
        // Add code above this line
    }
}